import React from 'react'
import { useEffect, useState } from 'react';
import axios from 'axios';

const Users = () => {
    const [Users, setUsers] = useState([]);
    // fires on component mounted and component updated.
    useEffect(() => {
        allCardData()
    },[]);
    // Fetch all data from API
    const allCardData = async () => {
        const  resp = await axios.get('http://10.208.66.112:8080/users');
        setUsers(resp.data);
    }
    return (
        <div >
             <h2 align='center'>User Details..</h2>
                <table border ='1'>
                    <thead>
                        <tr>
                            <th>Employe ID</th>
                            <th>Name</th>
                            <th>Password</th>
                            <th>Role</th>
                       </tr>
                    </thead>
                    <tbody>
                        {
                            Users.map(User=>(
                                <tr Key={User.empid}>
                                    <td>{User.empid}</td>
                                    <td>{User.name}</td>
                                    <td>{User.password}</td>
                                    <td>{User.roll}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>
        </div>
    )
}

export default Users;