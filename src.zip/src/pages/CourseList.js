import React from 'react'
import { useEffect, useState } from 'react';
import axios from 'axios';
import "../Table.css";
const CourseList = () => {
    const [courses, setCourses] = useState([]);
    // fires on component mounted and component updated.
    useEffect(() => {
        allCardData()
    },[]);
    // Fetch all data from API
    const allCardData = async () => {
        const  resp = await axios.get('http://10.208.66.112:8080/course');
        // const newArray =[]; 
        // for (const [key, value] of Object.entries(resp.data)) {
        //     const obj = {'label':value.bookname, 'value':value.bookid};
        //     newArray.push(obj);
        //     console.log(key+" : "+value.bookid+" : "+ value.bookname);
        // }
        setCourses(resp.data);
    }
    return (
        <div>
            <h2 align = 'center'> Course Details..</h2>
                <table border ='1'>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Author</th>
                            <th colSpan='2'>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            courses.map(course=>(
                                <tr Key={course.bookid}>
                                    <td>{course.bookid}</td>
                                    <td>{course.bookname}</td>
                                    <td>{course.author}</td>
                                    <td><button onClick={Delete}>Delete</button></td>
                                    <td><button onClick={Edit}>Modify</button></td>

                                </tr>
                            ))
                        }
                    </tbody>
                </table>
        </div>
    )
}
function Edit() {
    alert('Please Wait');
  }
  function Delete() {
    alert('Deleted');
  }




export default CourseList;
