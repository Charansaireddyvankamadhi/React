import React from 'react'
import img from '../Images/hcltech.jpg';

const Home = () => {
    return (
        <div //style={{display: 'justify',justifyContent:'justify',alignItems:'justify',height:'10vh'}}
        >
            <img src={img} alt="" width="1260" height="525"/>
        </div>
    )
}

export default Home
