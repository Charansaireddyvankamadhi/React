import React from 'react'
import img from '../Images/Image.jpg';


const About = () => {
    return (
        <div                                    //style={{display: 'fill',justifyContent:'fill',alignItems:'center',height:'100vh',}}
         >
          <img src={img} alt="" width="1300" height="530"/>
        </div>
    )
}

export default About
